package Homework2;

public class Student extends people {
      int bianhao;
      String name;
//      int course[];
      Course course;
      
      Student(int bianhao,String name,Course course){
    	  this.bianhao =bianhao;
    	  this.name = name;
    	  this.course = course;
      }
      Student(int bianhao,String name){
    	  this.bianhao =bianhao;
    	  this.name = name;
    	  
      }
      void tuike(){
    	  course=null;
      }
      public String toString() {
    	  return name+"  ��ţ�"+bianhao;
      }
      void showall() {
    	  if(course==null)
    	  {System.out.println("ѧ��Ŀǰδѡ��");}
    	  else {
    	  System.out.println("ѧ����"+name);
    	  System.out.println("ѡ��"+this.course);  
    	  }
      }
}
