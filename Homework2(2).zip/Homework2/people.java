package Homework2;

public class people {
      int bianhao;
      String name;
      String sex;
      
}
